import React from 'react'
import './feature.css'

const Feature = () => {
    return (
        <div>
            Feature
        </div>
    )
}

export default Feature
