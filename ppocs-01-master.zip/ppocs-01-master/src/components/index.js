// Here we will take all of our components and export them in one fail swoop for any import just by callint this index file and 'deconstucting' each component within the { braces }; 

export { default as Article } from './article/Article' ;
export { default as Brand } from './brand/Brand' ;
export { default as CTA } from './cta/Cta' ;
export { default as Feature } from './feature/Feature' ;
export { default as Navbar } from './navbar/Navbar' ;