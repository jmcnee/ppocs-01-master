import React from 'react'
import './whatgpt3.css'

const Whatgpt3 = () => {
    return (
        <div>
            Whatgpt3
        </div>
    )
}

export default Whatgpt3
